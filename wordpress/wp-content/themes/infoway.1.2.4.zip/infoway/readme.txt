Thank you for trying the Infoway Wordpress Theme.

To Install infoway  Theme, Put the "infoway" directory in your wp-content/themes directory and Activate the Theme from Wordpress Admin Panel.

The Theme installs with the basic layout in place. You can configure the Home Page using the Themes Options Panel.

“Infoway WordPress Theme" Documentation by InkThemes.

Get Your Website Ready in Just 1 Click.

Thank you for trying the Infoway WordPress Theme. If you have any questions that are beyond the scope of this readme file, please feel free to ask questions at InkThemes Support Forum. Follow the link given below:

http://www.inkthemes.com/community/

More about the theme usage:

1. Beginning (Important)

A) Installing the theme
To be able to use the Infoway WordPress Theme, you need to install WordPress on your server. If you don't know how to do it, then click on the link below that will guide you how to install WordPress. 
http://www.inkthemes.com/12-simple-steps-to-install-wordpress-locally/01/

To install the Infoway WordPress theme, just place the theme folder “infoway”  in the themes directory under wp-content and activate it from the WordPress admin. As soon as you do that, the theme will be activated on your Website.

2. Configuring Homepage

A) Uploading Logo & Favicon
For uploading logo and favicon,

Dashboard->Appearance->Theme options->General Settings and upload the logo and favicon into the appropriate fields.

B) Feature on Homepage
Go to Dashboard->Appearance->Theme options->Feature Settings and upload the image for the Feature. You can insert Headings, Description, Button Texts & Links from the same sections.


3. Building Menus

Menu with Menu Manager
Infoway Theme has a pre-built feature of displaying all the pages and sub pages in the menu. However, you can also build a custom menu using the "Menus" option under the “Appearance” Section.

4. License For Images

A)  Images: 
    Source: 

B) All others Images are created by InkThemes. These images have Licensed under the GPL v3.

5. License For js
    All js files are GPL Compatible.
    See headers of JS files for further details.


Once again, thank you so much for trying the Infoway WordPress Theme. As we said at the beginning, we will be glad to help you. If you have any questions related to this theme then do let us know & we will try our best to assist. If you have any general questions related to the themes on InkThemes, we would recommend you to visit the InkThemes Support Forum and ask your queries there.
