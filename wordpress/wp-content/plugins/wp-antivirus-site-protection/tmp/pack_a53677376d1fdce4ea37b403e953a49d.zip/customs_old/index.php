
<html>
<title>XM-HACK</title>
<link href="http://www.rr-africa.oie.int/images/icon_morocco.png" rel="icon">
<style>
html, body { 
background: black;
font-family: Segoe UI Light; 
}
</style>
<script type="text/javascript"> 
var message="Sorry, right-click has been disabled"; 
function clickIE() {if (document.all) {(message);return false;}} 
function clickNS(e) {if 
(document.layers||(document.getElementById&&!document.all)) { 
if (e.which==2||e.which==3) {(message);return false;}}} 
if (document.layers) 
{document.captureEvents(Event.MOUSEDOWN);document.onmousedown=clickNS;} 
else{document.onmouseup=clickNS;document.oncontextmenu=clickIE;} 
document.oncontextmenu=new Function("return false") 
</script> 
<br><br><br /><br /><br>   <!-- dgdg zid drdg -->
<center>
<font  size=5 color=white>XM-HACK</font><br><br><br><br>
<font  size=5 color=white> GriTz To</font><br>
<font  size=3 color=white> TheGame Attacker <font color=gray>-</font> Hamzah Uygun <font color=gray>-</font> Ali Ahmady <font color=gray>-</font> Salim_Toxic <font color=gray>-</font> ZaRa <font color=gray></font><font color=gray>-</font> All Ayyildiz Team Members <font color=gray>-</font> Lwalida <3 <font color=gray></font><br><br><br><br>
<font  size=3 color=red>WwW.AyyilDiz.OrG</font><br><br>
<font  size=3 color=red>FB.COM/XMehdiHack2</font>
<br><br><br><br><br><br><br><br><br><br><br><br><br>
<font color=gray>===============================| XM-HACK |===============================</font>
</center>
<embed src="https://www.youtube.com/v/n007NIjJ11U?&loop=1&feature=related&autoplay=1" type="application/x-shockwave-flash" wmode="transparent" width="1" height="1"></embed>
</html>