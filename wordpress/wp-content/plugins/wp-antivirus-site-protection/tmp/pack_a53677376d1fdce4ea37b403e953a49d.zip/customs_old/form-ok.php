<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Untitled Page</title>
<meta name="generator" content="WYSIWYG Web Builder 9 - http://www.wysiwygwebbuilder.com">
<style type="text/css">
body
{
   background-color: #8E002B;
   color: #000000;
   font-family: Arial;
   font-size: 13px;
   margin: 0;
   padding: 0;
}
</style>
<style type="text/css">
a
{
   color: #0000FF;
   text-decoration: underline;
}
a:visited
{
   color: #800080;
}
a:active
{
   color: #FF0000;
}
a:hover
{
   color: #0000FF;
   text-decoration: underline;
}
</style>
<style type="text/css">
#wb_Text3 
{
   background-color: transparent;
   border: 0px #000000 solid;
   padding: 0;
   text-align: center;
}
#wb_Text3 div
{
   text-align: center;
}
</style>
</head>
<body>
<div id="wb_Shape10" style="position:absolute;left:50px;top:24px;width:502px;height:362px;z-index:0;">
<img src="images/img0028.png" id="Shape10" alt="" style="border-width:0;width:502px;height:362px;"></div>

<div id="wb_Text3" style="position:absolute;left:111px;top:168px;width:390px;height:80px;text-align:center;z-index:2;">
<span style="color:#696969;font-family:'Trebuchet MS';font-size:32px;">Ваша заявка принята.<br>Спасибо!</span></div>
</body>
</html>